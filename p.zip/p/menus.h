#ifndef MENUS_H_INCLUDED
#define MENUS_H_INCLUDED

int menuModificar();
int menuOrdenar();
int getDireccion();
int menuPrincipal();

#endif // MENUS_H_INCLUDED
