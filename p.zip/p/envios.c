#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "envios.h"
#include "LinkedList.h"
#include "gets.h"
#include "Controller.h"
Envios* envios_new()
{
    Envios* pEnvios;
    pEnvios = (Envios*) calloc(sizeof(Envios),1);
    return pEnvios;
}
Envios* envios_newParametros(char* idStr,char* anioNacimiento,char* nombre,char* dni,char* fechaPresentacion,char* tema,char* puntaje)
{
    Envios* auxiliarEnvios = envios_new();

    if(auxiliarEnvios != NULL)
    {
        int id = atoi(idStr);
        envios_setId(auxiliarEnvios,id);

        int anio_Nacimiento = atoi(anioNacimiento);
        envios_setAnioNacimiento(auxiliarEnvios,anio_Nacimiento);
        envios_setNombre(auxiliarEnvios,nombre);
        int DNI = atoi(dni);
        //envios_setDni(auxiliarEnvios,DNI);
        //envios_setFechaPresentacion(auxiliarEnvios,fechaPresentacion);
        //envios_setTema(auxiliarEnvios,tema);
        int puntaje_int = atoi(puntaje);
        envios_setPuntaje(auxiliarEnvios,puntaje_int);
    }
    return auxiliarEnvios;


    return 0;
}
int envios_setId(Envios* this,int id)
{
    int set = 0;
    if(this !=NULL && id>0)
    {
        this->idEnvios = id;
        set = 1;
    }
    return set;
}
int envios_getId(Envios* this,int* id)
{
    int estado = 0;
    if(this !=NULL && id != NULL)
    {
        *id = this ->idEnvios;
        estado = 1;
    }

    return estado;
}
int envios_setNombre(Envios* this,char* nombre)
{
    int estado = 0;
    if(this != NULL && nombre != NULL)
    {
        if(strlen(nombre)!=0)
        {
            strcpy(this->nombre,nombre);
            estado = 1;
        }
    }
    return estado = 0;
}
int envios_getNombre(Envios* this,char* nombre)
{
    int estado = 0;
    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre,this->nombre);
        estado = 1;
    }
    return estado;
}
int envios_setAnioNacimiento(Envios* this,int anioNacimiento)
{
    int estado = 0;
    if(this != NULL && anioNacimiento > 0)
    {
        this ->anioNacimiento = anioNacimiento;
        estado = 1;
    }
    return estado;
}
int envios_getAnioNacimiento(Envios* this,int* anioNacimiento)
{
    int estado = 0;
    if(this != NULL)
    {
        *anioNacimiento = this ->anioNacimiento;
        estado = 1;
    }
    return estado;
}
/*int envios_setDni(Envios* this,int dni)
{
    int estado = 0;
    if(this != NULL && dni > 0)
    {
        this ->dni = dni;
        estado = 1;
    }
    return estado;
}
int envios_getDni(Envios* this,int* dni)
{
    int estado = 0;
    if(this != NULL)
    {
        *dni = this ->dni;
        estado = 1;
    }
    return estado;
}
int envios_setFechaPresentacion(Envios* this,char* fechaPresentacion)
{
    int estado = 0;
    if(this != NULL && fechaPresentacion != NULL)
    {
        strcpy(this->fechaPresentacion,fechaPresentacion);
        estado = 1;
    }
    return estado;
}
int envios_getFechaPresentacion(Envios* this,char* fechaPresentacion)
{
    int estado = 0;
    if(this != NULL)
    {
        strcpy(fechaPresentacion,this->fechaPresentacion);
        estado = 1;
    }
    return estado;
}
int envios_setTema(Envios* this,char* tema)
{
    int estado = 0;
    if(this != NULL && tema!= NULL)
    {
        strcpy(this->tema,tema);
        estado = 1;
    }
    return estado;
}
int envios_getTema(Envios* this,char* tema)
{
    int estado = 0;
    if(this != NULL)
    {
        strcpy(tema,this->tema);
        estado = 1;
    }
    return estado;
}*/
int envios_setPuntaje(Envios* this,int puntaje)
{
    int estado = 0;
    if(this != NULL && puntaje > 0)
    {
        this ->puntaje = puntaje;
        estado = 1;
    }
    return estado;
}
int envios_getPuntaje(Envios* this,int* puntaje)
{
    int estado = 0;
    if(this != NULL)
    {
        *puntaje = this ->puntaje;
        estado = 1;
    }
    return estado;
}
/*int envios_set_segundoPuntaje(Envios* this,int segundoPuntaje)
{
    int set = 0;
    if(this !=NULL)
    {
        this->puntajeSegundaRonda = segundoPuntaje;
        set = 1;
    }
    return set;
}
int envios_getSegundoPuntaje(Envios* this,int* segundoPuntaje)
{
    int estado = 0;
    if(this != NULL)
    {
        *segundoPuntaje = this->puntajeSegundaRonda;
        estado = 1;
    }
    return estado;
}
int envios_set_promedio(Envios* this,float promedio)
{
    int set = 0;
    if(this !=NULL)
    {
        this->promedioPuntajes = promedio;
        set = 1;
    }
    return set;
}
int envios_getPromedio(Envios* this,float* promedio)
{
    int estado = 0;
    if(this != NULL)
    {
        *promedio = this->promedioPuntajes;
        estado = 1;
    }
    return estado;
}
int envios_setTercerPuntaje(Envios* this,int tercerPuntaje)
{
    int set = 0;
    if(this !=NULL && tercerPuntaje>0)
    {
        this->tercerPuntaje = tercerPuntaje;
        set = 1;
    }
    return set;
}
int envios_getTercerPuntaje(Envios* this,int* tercero)
{
    int estado = 0;
    if(this != NULL)
    {
        *tercero = this ->tercerPuntaje;
        estado = 1;
    }
    return estado;
}*/
int calcular_segundo_puntaje(void* pElement)
{
    int estado = -1;
    Envios* aux;
    int numero;
    if(pElement !=NULL)
    {
        aux = (Envios*)pElement;
        numero = getNumeroAleatorio(0,100);
       // envios_set_segundoPuntaje(aux,numero);
        estado = 0;
    }
    return estado;
}
int envios_mostrar_segundo_puntaje(LinkedList* pArrayListEnvios)
{
    //LinkedList* pArrayListConcursante
    int estado = -1;
    if(pArrayListEnvios !=NULL)
    {
        system("cls");
        printf("Listado de concursantes con segundo puntaje y promedio de ambos puntajes:\n\n");
        Envios* pEnviosAux;
        int idAux,anioNacimientoAux,dniAux,puntajeAux,segundoPuntaje;
        float promedio;
        char nombreAux[50];
        char fechaPresentacionAux[50];
        char temaAux[50];
        int len = ll_len(pArrayListEnvios);
        if(pArrayListEnvios !=NULL && len >0)
        {
            printf("Id------AnioNacimiento-----Nombre-----Dni----FechaPresentacion----Tema----------Puntaje-----SegundoPuntaje----Promedio\n");
            for(int i =0;i<len;i++)
            {
                pEnviosAux = ll_get(pArrayListEnvios,i);
                envios_getId(pEnviosAux,&idAux);
                envios_getAnioNacimiento(pEnviosAux,&anioNacimientoAux);
                envios_getNombre(pEnviosAux,nombreAux);
                //envios_getDni(pEnviosAux,&dniAux);
                //envios_getFechaPresentacion(pEnviosAux,fechaPresentacionAux);
                //envios_getTema(pEnviosAux,temaAux);
                envios_getPuntaje(pEnviosAux,&puntajeAux);
                //envios_getSegundoPuntaje(pEnviosAux,&segundoPuntaje);
                //envios_getPromedio(pEnviosAux,&promedio);
                printf("%d  %15d  %15s %5d %13s %15s %15d %15d %15.2f\n",idAux,anioNacimientoAux,nombreAux,dniAux,fechaPresentacionAux,temaAux,puntajeAux,segundoPuntaje,promedio);
            }
            estado = 1;
        }
    }
    return estado;
}
int calcular_promedio_puntaje(void* pElement)
{
    int estado = -1;
    Envios* aux;
    float promedio;
    int* puntajePrimeraRonda = NULL;
    int* puntajeSegundaRonda = NULL;
    int primero,segundo;
    int suma;
    if(pElement !=NULL)
    {
        aux = (Envios*)pElement;
        puntajePrimeraRonda = &primero;
        puntajeSegundaRonda = &segundo;
        envios_getPuntaje(aux,puntajePrimeraRonda);
        //envios_getSegundoPuntaje(aux,puntajeSegundaRonda);
        suma = *puntajePrimeraRonda + *puntajeSegundaRonda;
        promedio = (float)suma / 2;
        //envios_set_promedio(aux,promedio);
        estado = 0;
    }
    return estado;
}
int envios_contar_puntaje_menorA10(void* pElement)
{
    int contador = 0;
    Envios* aux;
    int puntaje;
    int dni;
    char path[25];
    char dniChar[25];
    if(pElement != NULL)
    {
        aux = pElement;
        envios_getPuntaje(aux,&puntaje);
        if(puntaje <10)
        {
            contador = 1;
            //envios_getDni(aux,&dni);
            itoa(dni,dniChar,10);
            strcpy(path,dniChar);
            strcat(path,".csv");
            //controller_enviosSaveAsText(path,aux);
        }
    }
    return contador;
}
int primer_puntaje_mayorA70(void* pElement)
{
    int contador = 0;
    Envios* aux;
    int puntaje;
    int dni;
    char path[25];
    char dniChar[25];
    if(pElement != NULL)
    {
        aux = pElement;
        envios_getPuntaje(aux,&puntaje);
        if(puntaje > 70)
        {
            contador = 1;
            //envios_getDni(aux,&dni);
            itoa(dni,dniChar,10);
            strcpy(path,dniChar);
            strcat(path,".csv");
//            controller_enviosSaveAsText(path,aux);
        }
    }
    return contador;
}
int concursante_mejor_promedio(void* pElement,void* maximo)
{
    int estado;
    float promedioEmpleado;
    float* promedioMaximo;
    int dni;
    char path[25];
    char dniChar[25];
    Envios* aux;
    if(pElement != NULL && maximo !=NULL)
    {
        estado = 0;
        aux = (Envios*)pElement;
      //  envios_getPromedio(aux,&promedioEmpleado);
        promedioMaximo = (float*)maximo;
        if(promedioEmpleado == *promedioMaximo)
        {
         //   envios_getDni(aux,&dni);
            itoa(dni,dniChar,10);
            strcpy(path,dniChar);
            strcat(path,".csv");
//            controller_enviosSaveAsText(path,aux);
            estado = 1;
        }
    }
    return estado;
}
float envios_sacar_promedio_maximo(LinkedList* pArray)
{
    Envios* aux;
    float maximo;
    float promedio;
    int len;
    if(pArray != NULL)
    {
        len = ll_len(pArray);
        for(int i=0;i<len;i++)
        {
            aux = (Envios*)ll_get(pArray,i);
           // envios_getPromedio(aux,&promedio);
            if(i==0)
            {
                maximo = promedio;
            }
            else{
                if(promedio > maximo)
                {
                    maximo = promedio;
                }
            }
        }
    }
    return maximo;
}
int envios_sacar_nota_maxima(LinkedList* pArray)
{
    Envios* aux;
    int maximo;
    int primeraNota;
    int len;
    if(pArray != NULL)
    {
        len = ll_len(pArray);
        for(int i=0;i<len;i++)
        {
            aux = (Envios*)ll_get(pArray,i);
            envios_getPuntaje(aux,&primeraNota);
            if(i==0)
            {
                maximo = primeraNota;
            }
            else{
                if(primeraNota > maximo)
                {
                    maximo = primeraNota;
                }
            }
        }
    }
    return maximo;
}
int envios_mejor_nota(void* pElement,void* maximo)
{
    int estado;
    int notaEnvios;
    int* notaMaxima;
    int dni;
    char path[25];
    char dniChar[25];
    Envios* aux;
    if(pElement != NULL && maximo !=NULL)
    {
        estado = 0;
        aux = (Envios*)pElement;
        envios_getPuntaje(aux,&notaEnvios);
        notaMaxima = (int*)maximo;
        if(notaEnvios == *notaMaxima)
        {
           // envios_getDni(aux,&dni);
            itoa(dni,dniChar,10);
            strcpy(path,dniChar);
            strcat(path,".csv");
//            controller_enviosSaveAsText(path,aux);
            estado = 1;
        }
    }
    return estado;
}
int envios_3_finalistas(void* pElement,int contador)
{
    int estado;
    int dni;
    char path[25];
    char dniChar[25];
    Envios* aux;
    if(pElement != NULL)
    {
        estado = 0;
        aux = (Envios*)pElement;
        //envios_getPuntaje(aux,&notaConcursante);
        if(contador != 3)
        {
           // envios_getDni(aux,&dni);
            itoa(dni,dniChar,10);
            strcpy(path,dniChar);
            strcat(path,".csv");
           // controller_enviosSaveAsText(path,aux);
            estado = 1;
        }
    }
    return estado;
}


/*int gano_primera_ronda(void* pElement)
{
    int estado = 0;
    Concursante* aux;
    if(pElement != NULL)
    {
        aux = (Concursante*)pElement;
        if(aux->puntaje >=90)
        {
            estado = 1;
        }
    }
    return estado;
}
*/

/*void mostrar_menos_diez_primer_puntaje(LinkedList* pArray,void* pElement)
{
    int cantidad;
    Concursante* aux;
    if(pArray != NULL && pElement !=NULL)
    {
        aux = (Concursante*)pElement;
        cantidad = ll_count(pArray,aux);
        printf("La cantidad de concursantes que tienen menos de 10 en el primer puntaje es  %d",cantidad);
    }
}
*/
/*
void employee_delete(Employee* this)
{
    if(this !=NULL)
    {
        free(this);
    }
}
*/
int employee_sortByPuntaje(void* enviosA,void* enviosB)
{
    int sort;
    if(enviosA !=NULL && enviosB !=NULL)
    {
        int puntajeA;
        int puntajeB;
        envios_getPuntaje(enviosA,&puntajeA);
        envios_getPuntaje(enviosB,&puntajeB);
        if(puntajeA>puntajeB)
        {
            sort = 1;
        }
        else if(puntajeA == puntajeB)
        {
            sort = 0;
        }
        else{
            sort = -1;
        }
    }
    return sort;
}
int calcular_tercer_puntaje(void* pElement)
{
    int estado = -1;
    Envios* aux;
    int numero;
    if(pElement !=NULL)
    {
        aux = (Envios*)pElement;
        numero = getNumeroAleatorio(0,100);
        estado = 0;
    }
    return estado;
}
int envios_mostrar_tercer_puntaje(LinkedList* pArrayListEnvios)
{
    //LinkedList* pArrayListConcursante
    int estado = -1;
    if(pArrayListEnvios !=NULL)
    {
        system("cls");
        printf("Listado de envios con tercer puntaje:\n\n");
        Envios* pEnviosAux;
        int idAux,anioNacimientoAux,dniAux,puntajeAux,segundoPuntaje,tercerPuntaje;
        float promedio;
        char nombreAux[50];
        char fechaPresentacionAux[50];
        char temaAux[50];
        int len = ll_len(pArrayListEnvios);
        if(pArrayListEnvios !=NULL && len >0)
        {
            printf("Id------AnioNacimiento-----Nombre-----Dni----FechaPresentacion----Tema----------Puntaje-----SegundoPuntaje----Promedio-----------puntaje3\n");
            for(int i =0;i<len;i++)
            {
                pEnviosAux = ll_get(pArrayListEnvios,i);
                envios_getId(pEnviosAux,&idAux);
                envios_getAnioNacimiento(pEnviosAux,&anioNacimientoAux);
                envios_getNombre(pEnviosAux,nombreAux);
                envios_getPuntaje(pEnviosAux,&puntajeAux);
                printf("%d  %15d  %15s %5d %13s %15s %15d %15d %15.2f %10d\n",idAux,anioNacimientoAux,nombreAux,dniAux,fechaPresentacionAux,temaAux,puntajeAux,segundoPuntaje,promedio,tercerPuntaje);
            }
            estado = 1;
        }
    }
    return estado;
}
int employee_sortByTercerPuntaje(void* enviosA,void* enviosB)
{
    int sort;
    if(enviosA !=NULL && enviosB !=NULL)
    {
        int puntajeA;
        int puntajeB;
        if(puntajeA>puntajeB)
        {
            sort = 1;
        }
        else if(puntajeA == puntajeB)
        {
            sort = 0;
        }
        else{
            sort = -1;
        }
    }
    return sort;
}
/*
int employee_sortByNombre(void* empleadoA,void* empleadoB)
{
    int sort;
    char nombreA[51];
    char nombreB[51];
    if(empleadoA != NULL && empleadoB !=NULL)
    {
        employee_getNombre(empleadoA, nombreA);
        employee_getNombre(empleadoB, nombreB);

        sort = strcmp(nombreA,nombreB);
    }
    return sort;
}
int employee_sortByHorasTrabajadas(void* empleadoA,void* empleadoB)
{
    int sort;
    if(empleadoA != NULL && empleadoB !=NULL)
    {
        int HorasA;
        int HorasB;
        employee_getHorasTrabajadas(empleadoA, &HorasA);
        employee_getHorasTrabajadas(empleadoB, &HorasB);
        if(HorasA >HorasB)
        {
            sort = 1;
        }
        else if(HorasA == HorasB)
        {
            sort = 0;
        }
        else
        {
            sort = -1;
        }
    }
    return sort;
}
int employee_sortBySueldo(void* empleadoA,void* empleadoB)
{
    int sort;
    if(empleadoA !=NULL && empleadoB !=NULL)
    {
        int sueldoA;
        int sueldoB;

        employee_getSueldo(empleadoA, &sueldoA);
        employee_getSueldo(empleadoB, &sueldoB);

        if(sueldoA >sueldoB)
        {
            sort = 1;
        }
        else if(sueldoA == sueldoB)
        {
            sort = 0;
        }
        else
        {
            sort = -1;
        }
    }
    return sort;
}
*/
