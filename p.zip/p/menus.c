#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menus.h"
#include "LinkedList.h"
#include "Controller.h"
#include "gets.h"
#include "envios.h"

int menuPrincipal()
{
    int opcion;
    printf("PARCIAL LAB NUMERO 2:\n\n");
    printf("1-Cargar los datos de los envios desde el archivo data.csv (modo texto)\n");
    //printf("2-Cargar los datos de los envios desde el archivo data.csv (modo binario).\n");
    printf("3-Listar envios\n");
    printf("6-Generar un archivo por cada elemento que cumpla la funcion anterior\n");
    printf("12-Salir\n");
    printf("Ingrese una opcion:");
    scanf("%d",&opcion);
    return opcion;
}

int menuModificar()
{
    int opcion;
    system("cls");
    printf("MODIFICAR EMPLEADO:\n\n");
    printf("1-Nombre\n");
    printf("2-Horas trabajadas\n");
    printf("3-Salario\n");
    printf("4-Salir\n");
    opcion = new_get_Int("Ingrese una opcion:");

    return opcion;
}
int menuOrdenar()
{
    system("cls");
    int option;
    printf("ORDENAR EMPLEADOS:\n\n");
    printf("Metodos:\n");
    printf("1-Empleados ordenados por ID\n");
    printf("2-Empleados ordenados por nombre\n");
    printf("3-Empleados ordenados por horas trabajadas\n");
    printf("4-Empleados ordenados por salario\n");
    option = getInt("Seleccione un metodo:");

    return option;
}

int getDireccion()
{
    system("cls");
    int optionDireccion;
    printf("ELIJA EL SENTIDO DE ORDENAMIENTO:\n\n");
    printf("1-Ascendente\n");
    printf("2-Descendente\n");
    printf("3-Salir\n");
    do
    {
        optionDireccion = getInt("Ingrese algun sentido:");
        switch(optionDireccion)
        {
        case 1:
            optionDireccion = 1;
            break;
        case 2:
            optionDireccion = 0;
            break;
        }
        return optionDireccion;
    }
    while(optionDireccion != 3);
}
void opciones_principales_linkedList(LinkedList* listaEnvios)
{
    char path[25];
    //char newPath[] = "resultado ";
    int flag = 0;
    int option;
    do{
        option = menuPrincipal();
        switch(option)
        {
            case 1:
                if(flag == 0)
                {
                    get_String(path,25,"Ingrese el nombre del archivo csv desde el cual leera los datos:","Ese nombre es incorrecto,reingrese nombre:");
                    controller_loadFromText(path,listaEnvios);
                    //controller_loadFromText("MOCK_DATA_final.csv",listaEnvios);
                    flag = 1;
                    system("pause");
                }
                else{
                    printf("Ya se cargaron datos\n");
                    system("pause");
                }
                break;
            /*case 2:
                if(flag == 0)
                {*/
                    //controller_loadFromBinary("buenosaires.bin",listaEnvios);
                    /*flag = 1;
                    system("pause");
                }
                else{
                    printf("Ya se cargaron datos\n");
                    system("pause");
                }
                break;*/
            case 3:
                if(flag == 1)
                {
                    controller_ListEnvios(listaEnvios);
                    system("pause");
                }
                else{
                    printf("Primero cargue los datos\n");
                    system("pause");
                }
                break;
            case 6:
                if(flag == 1)
                {
                    printf("MEJORADO...\n");
                    system("pause");
                }
                else{

                    system("pause");
                }
                break;
            case 12:
                printf("Gracias por usar el programa\n");
                break;
        }
        system("cls");
    }while(option != 12);
}

