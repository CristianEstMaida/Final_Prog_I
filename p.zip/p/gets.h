#ifndef GETS_H_INCLUDED
#define GETS_H_INCLUDED

int getInt (char mensaje[]);

float getFloat (char mensaje[]);

char getChar(char mensaje[]);

void getString(char mensaje[], char input[]);
int new_get_Int(char mensaje[]);
int getNumeroAleatorio(int desde , int hasta);
void get_String(char string[],int len,char message[],char errorMessage[]);
int isOnlyLetters(char str[]);


#endif // GETS_H_INCLUDED

