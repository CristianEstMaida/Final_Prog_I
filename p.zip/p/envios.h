#ifndef ENVIOS_H_INCLUDED
#define ENVIOS_H_INCLUDED

typedef struct
{
    int idEnvios;
    int anioNacimiento;
    char nombre[51];
    int puntaje;
}Envios;

#endif // ENVIOS_H_INCLUDED

Envios* envios_new();
Envios* envios_newParametros(char* idStr,char* anioNacimiento,char* nombre,char* dni,char* fechaPresentacion,char* tema,char* puntaje);
int envios_setId(Envios* this,int id);
int envios_getId(Envios* this,int* id);
int envios_setNombre(Envios* this,char* nombre);
int envios_getNombre(Envios* this,char* nombre);
int envios_setAnioNacimiento(Envios* this,int anioNacimiento);
int envios_getAnioNacimiento(Envios* this,int* anioNacimiento);
int envios_setDni(Envios* this,int dni);
int envios_getDni(Envios* this,int* dni);
int envios_setTema(Envios* this,char* tema);
int envios_getTema(Envios* this,char* tema);
int envios_setPuntaje(Envios* this,int puntaje);
int envios_getPuntaje(Envios* this,int* puntaje);
/////
int calcular_segundo_puntaje(void* pElement);
int calcular_promedio_puntaje(void* pElement);
int envios_getPromedio(Envios* this,float* promedio);
int envios_set_promedio(Envios* this,float promedio);
///////
int controller_enviosSaveAsText(char* path,Envios* dato);
