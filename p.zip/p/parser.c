#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "envios.h"


int parser_enviosFromText(FILE* pFile , LinkedList* pListaEnvios)
{
    Envios* auxEnvios = envios_new();
    int r;
    int i = 0;
    char idAux[50];
    char anioNacimientoAux[50];
    char nombreAux[50];
    char dni[50];
    char fechaPresentacion[50];
    char tema[50];
    char puntaje[50];

    r = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,\n]\n",idAux,anioNacimientoAux,nombreAux,dni,fechaPresentacion,tema,puntaje);
    while(!feof(pFile))
    {
        r = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,\n]\n",idAux,anioNacimientoAux,nombreAux,dni,fechaPresentacion,tema,puntaje);
        if(r==7)
        {
            auxEnvios = envios_newParametros(idAux,anioNacimientoAux,nombreAux,dni,fechaPresentacion,tema,puntaje);
            ll_add(pListaEnvios,auxEnvios);
            i++;
        }
    }
    printf("Se cargaron %d envios a la lista en modo texto\n",i);
    return i;

}
int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee)
{
    //Employee empleadoAux;
    int i = 0;

    //fread(&empleadoAux, sizeof(Employee), 1, pFile);

    while(!feof(pFile))
    {
        /*Employee *empleadoNuevo = employee_new();
        employee_setId(empleadoNuevo,empleadoAux.id);
        employee_setHorasTrabajadas(empleadoNuevo,empleadoAux.horasTrabajadas);
        employee_setNombre(empleadoNuevo,empleadoAux.nombre);
        employee_setSueldo(empleadoNuevo,empleadoAux.sueldo);
        i ++;
        ll_add(pArrayListEmployee,empleadoNuevo);
        fread(&empleadoAux,sizeof(Employee),1,pFile);
        */
    }
    printf("Se cargaron %d envios a la lista (modo binario) \n", i);
    return 1;
}

